package com.example.apploginadmin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.sql.SQLException;

public class GestionUsuarios extends AppCompatActivity
{
    private EditText TextNombreUser;
    private EditText TextConUser;
    private Button botonCrear;
    private Button botonBorrar;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gestion_usuarios);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) ->
        {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextNombreUser = findViewById(R.id.TextNombreUser);

        TextConUser = findViewById(R.id.TextConUser);

        botonCrear = findViewById(R.id.botonCrear);

        botonBorrar = findViewById(R.id.botonBorrar);

        String user = TextNombreUser.getText().toString().trim();
        String pass = TextConUser.getText().toString().trim();
        ConexionBD cb = new ConexionBD();
        botonCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                    String compUser = cb.comprobarUser(user);
                    if (user.equals(compUser))
                    {
                        Toast.makeText(GestionUsuarios.this, "Usuario existente", Toast.LENGTH_SHORT).show();

                    }
                    else
                    {
                        if (pass.length() >= 8)
                        {
                            cb.insertarUsuario(user, pass);
                            Toast.makeText(GestionUsuarios.this, "¡Usuario creado con exito!", Toast.LENGTH_SHORT).show();

                        }
                        else
                        {
                            Toast.makeText(GestionUsuarios.this, "Contraseña inferior a 8 caracteres", Toast.LENGTH_SHORT).show();

                        }


                    }
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }

            }
        });
        botonBorrar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                try
                {
                    String compUser = cb.comprobarUser(user);
                    if (user.equals(compUser))
                    {
                        cb.eliminarUsuario(user,pass);

                        Toast.makeText(GestionUsuarios.this, "¡Usuario eliminado con exito!", Toast.LENGTH_SHORT).show();

                    }
                    else
                    {
                        Toast.makeText(GestionUsuarios.this, "¡El usuario no existe!", Toast.LENGTH_SHORT).show();

                    }
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }

            }
        });
    }
}