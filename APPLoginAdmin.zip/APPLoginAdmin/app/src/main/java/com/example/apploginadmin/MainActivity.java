package com.example.apploginadmin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity
{
    private EditText textFieldUser;
    private EditText TextFieldPassword;
    private Button botonEntrar;
    private Button botonVer;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) ->
        {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textFieldUser = findViewById(R.id.TextFieldUser);
        TextFieldPassword = findViewById(R.id.TextFieldPassword);
        botonEntrar = findViewById(R.id.BotonEntrar);
        botonVer = findViewById(R.id.botonVer);
        String user = textFieldUser.getText().toString().trim();
        String pass = TextFieldPassword.getText().toString().trim();


        botonEntrar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

                if(user.equals("admin") && pass.equals("1234"))
                {
                    Intent i = new Intent(MainActivity.this,GestionUsuarios.class);
                    startActivity(i);


                }
                else
                {

                    Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();

                }

            }
        });

        botonVer.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

                if(user.equals("admin") && pass.equals("1234"))
                {
                    Intent i = new Intent(MainActivity.this,VerUsuarios.class);
                    startActivity(i);


                }
                else
                {

                    Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();

                }

            }
        });

    }

}