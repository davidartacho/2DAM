package Vistas;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Clase encargada de la gestion de la base de datos
 */
public class ConexionBD 
{
	//Aqui estan los datos de la base de datos
    private static String url = "jdbc:postgresql://172.26.19.127:5432/APP";
    private static String driver = "org.postgresql.Driver";
    private static Connection cn;
    private static String usuario = "postgres";
    private static String contrasenia = "root";
    
    
    //Aqui se crea la conexión con la base de datos la cual se usará apartir de ahora
    public static Connection getConnection() 
    {
        try {
            Class.forName(driver);
            cn = DriverManager.getConnection(url,usuario,contrasenia);
           
            return cn;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    //En este metodo se comprueba si existe un usuario con el mismo nombre para que no se puedan crear dos usuarios iguales
    public String comprobarUser(String usuario,String contrasena) throws SQLException 
    {
        Connection con = ConexionBD.getConnection();
        String query = "SELECT user_name FROM USUARIOS WHERE user_name = ? and password = ? and borrado = false";//Se comprueba si el usuario existe en la base de datos
        
        try 
        {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, usuario); 
            ps.setString(2, contrasena); 
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) 
            {
                String foundUsername = resultSet.getString("user_name");
                return foundUsername;
            }
            else 
            {
                return "User not found.";
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            return "Error occurred while checking user.";
        } 
      
        }
   
  
}

