package Vistas;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;



public class LoginUsuario extends JFrame {
	

	//Elementos de la ventana
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldUser;
	private JLabel lblNewLabel_1;
	private JTextField textFieldcon;
	private JButton btnEntrar;
	private JLabel lblNewLabel_2;
	private JLabel textoOculto;
	private JButton btnVerUsuarios;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUsuario frame = new LoginUsuario();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public LoginUsuario() 
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 332);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Usuario:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(118, 86, 61, 14);
		contentPane.add(lblNewLabel);
		
		textFieldUser = new JTextField();
		textFieldUser.setBounds(245, 83, 133, 27);
		contentPane.add(textFieldUser);
		textFieldUser.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Contraseña:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(118, 135, 100, 14);
		contentPane.add(lblNewLabel_1);
		
		textFieldcon = new JTextField();
		textFieldcon.setBounds(245, 129, 133, 27);
		contentPane.add(textFieldcon);
		
		btnEntrar = new JButton("Entrar");
		btnEntrar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnEntrar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				ConexionBD cb = new ConexionBD();
				String usuario = textFieldUser.getText();
				String con = textFieldcon.getText();
				
				try {
					if(usuario.equals(cb.comprobarUser(usuario,con)))
					{
						
						VentanaSecundaria user1 = new VentanaSecundaria();
						
						user1.setVisible(true);
						
						
					}
					else
					{
						textoOculto.setText("Usuario o contraseña inválidos");
						
					}
				} 
				catch (SQLException e1)
				{
					e1.printStackTrace();
				}
				
				
			}
		});
		btnEntrar.setBounds(118, 186, 116, 41);
		contentPane.add(btnEntrar);
		
		lblNewLabel_2 = new JLabel("Acceso del User");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 33));
		lblNewLabel_2.setBounds(111, 11, 309, 41);
		contentPane.add(lblNewLabel_2);
		
		textoOculto = new JLabel("");
		textoOculto.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textoOculto.setForeground(new Color(255, 0, 0));
		textoOculto.setBounds(118, 238, 313, 44);
		contentPane.add(textoOculto);
		
		
	}
	

}
