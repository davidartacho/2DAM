package PaqueteLogin;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ConexionBD {
    private static String url = "jdbc:postgresql://172.26.19.127:5432/APP";
    private static String driver = "org.postgresql.Driver";
    private static Connection cn;
    private static String usuario = "postgres";
    private static String contrasenia = "root";
    
    
    
    public static Connection getConnection() {
        try {
            Class.forName(driver);
            cn = DriverManager.getConnection(url,usuario,contrasenia);
           
            return cn;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    /*
    public boolean comprobarUser(String usuario , String con) throws SQLException 
    {
    	String query = "";
    	query = "SELECT user_name,password FROM USUARIOS WHERE user_name =  " + usuario + " AND password = " + con ;
    	Connection conn = DriverManager.getConnection(url,usuario,contrasenia);
    	Statement st = conn.createStatement();
    	
    	ResultSet resultSet = st.executeQuery(query);
    	
    	
    	if(resultSet.next())
    	{
    		return true;
    		
    	}
    	else
    	{
    		return false;
    	
    	}
    }
    */
    public static void eliminarUsuario(String usuario,String contrasena) throws SQLException
    {
    	Connection con = ConexionBD.getConnection();
    	String query = "UPDATE Usuarios SET user_name = ? , password = ? , borrado = ? where user_name = ? and password = ?";

    	     PreparedStatement ps = con.prepareStatement(query);

    	     ps.setString(1, usuario); 
    	     ps.setString(2, contrasena); 
    	     ps.setBoolean(3, true); 
    	     ps.setString(4, usuario);
    	     ps.setString(5, contrasena);
    	    ps.executeUpdate();
    	    
         
        
    }
    public static void mostrarUsuarios() throws SQLException
    {
    	Connection con = ConexionBD.getConnection();
    	String query = "SELECT user_name, password FROM Usuarios WHERE borrado = false";
    	PreparedStatement ps = con.prepareStatement(query);

    	ResultSet rs = ps.executeQuery();

       
        JFrame frame = new JFrame("Usuarios Activos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[] columnNames = {"Nombre", "Contraseña"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        while (rs.next())
        { 
            String nombre = rs.getString("nombre");
            String contraseña = rs.getString("contraseña");
            tableModel.addRow(new Object[]{nombre, contraseña});
        }

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.pack();
        frame.setVisible(true);
    

    }
    		
    	
  

    public static void insertarUsuario(String usuario,String contrasena) throws SQLException
    {
    	Connection con = ConexionBD.getConnection();
        String query="INSERT INTO USUARIOS (user_name, password, borrado) values (?, ?, ?)";
         PreparedStatement ps = con.prepareStatement(query);

         ps.setString(1, usuario);
         ps.setString(2, contrasena);
         ps.setBoolean(3, false);
         ps.executeUpdate();
    	
    }
    public static void main(String[] args) {
        Connection pruebacn = ConexionBD.getConnection();
        if (pruebacn != null) {
            System.out.println("Conexión realizada con éxito");
            System.out.println(pruebacn);
        } else {
            System.out.println("Desconectado");
        }
    }
}



