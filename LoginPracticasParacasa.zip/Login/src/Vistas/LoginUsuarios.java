package Vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PaqueteLogin.ConexionBD;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class LoginUsuarios extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldUser;
	private JTextField textFieldCon;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUsuarios frame = new LoginUsuarios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginUsuarios() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textFieldUser = new JTextField();
		textFieldUser.setBounds(201, 77, 99, 20);
		contentPane.add(textFieldUser);
		textFieldUser.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nombre");
		lblNewLabel.setBounds(128, 80, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Contraseña");
		lblNewLabel_1.setBounds(128, 133, 67, 14);
		contentPane.add(lblNewLabel_1);
		
		textFieldCon = new JTextField();
		textFieldCon.setBounds(201, 130, 99, 20);
		contentPane.add(textFieldCon);
		textFieldCon.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Usuarios");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 33));
		lblNewLabel_2.setBounds(150, 11, 138, 30);
		contentPane.add(lblNewLabel_2);
		
		JButton btnCrearUser = new JButton("Crear Usuario");
		btnCrearUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexionBD cb = new ConexionBD();
				
				try {
					cb.insertarUsuario(textFieldUser.getText(), textFieldCon.getText());
					JOptionPane.showMessageDialog(btnCrearUser, "¡Usuario creado con exito!", "Mensaje de Información", JOptionPane.INFORMATION_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
			}
		});
		btnCrearUser.setBounds(99, 181, 125, 47);
		
		contentPane.add(btnCrearUser);
		
		JButton btnBorrarUser = new JButton("Borrar Usuario");
		btnBorrarUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexionBD cb = new ConexionBD();
				
				try {
					cb.eliminarUsuario(textFieldUser.getText(), textFieldCon.getText());
					JOptionPane.showMessageDialog(btnBorrarUser, "¡Usuario eliminado con exito!", "Mensaje de Información", JOptionPane.INFORMATION_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
			}
		});
		btnBorrarUser.setBounds(245, 181, 125, 47);
		contentPane.add(btnBorrarUser);
	}
}
