package PaqueteLogin;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Clase encargada de la gestion de la base de datos
 */
public class ConexionBD 
{
	//Aqui estan los datos de la base de datos
    private static String url = "jdbc:postgresql://172.26.19.127:5432/APP";
    private static String driver = "org.postgresql.Driver";
    private static Connection cn;
    private static String usuario = "postgres";
    private static String contrasenia = "root";
    
    
    //Aqui se crea la conexión con la base de datos la cual se usará apartir de ahora
    public static Connection getConnection() 
    {
        try {
            Class.forName(driver);
            cn = DriverManager.getConnection(url,usuario,contrasenia);
           
            return cn;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    //En este metodo se comprueba si existe un usuario con el mismo nombre para que no se puedan crear dos usuarios iguales
    public String comprobarUser(String usuario) throws SQLException 
    {
        Connection con = ConexionBD.getConnection();
        String query = "SELECT user_name FROM USUARIOS WHERE user_name = ? and borrado = false";//Se comprueba si el usuario existe en la base de datos
        
        try 
        {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, usuario); 

            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) 
            {
                String foundUsername = resultSet.getString("user_name");
                return foundUsername;
            }
            else 
            {
                return "User not found.";
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            return "Error occurred while checking user.";
        } 
      
        }
   //Aqui se elimina el usuario que queramos de la base de datos
    public static void eliminarUsuario(String usuario,String contrasena) throws SQLException
    {
    	Connection con = ConexionBD.getConnection();
    	String query = "UPDATE Usuarios SET user_name = ? , password = ? , borrado = ? where user_name = ? and password = ?";

    	     PreparedStatement ps = con.prepareStatement(query);
    	     
    	     //Se ponen los datos del update
    	     ps.setString(1, usuario); 
    	     ps.setString(2, contrasena); 
    	     ps.setBoolean(3, true); 
    	     ps.setString(4, usuario);
    	     ps.setString(5, contrasena);
    	     ps.executeUpdate();
    	     
        
    }
    
    //Creamos un metodo para la visualización de los usuarios de la base de datos
    public static void mostrarUsuarios() throws SQLException
    {
    	Connection con = ConexionBD.getConnection();
    	String query = "SELECT user_name, password FROM Usuarios WHERE borrado = false";
    	PreparedStatement ps = con.prepareStatement(query);

    	ResultSet rs = ps.executeQuery();

       
        JFrame frame = new JFrame("Usuarios Activos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[] columnNames = {"Nombre", "Contraseña"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        while (rs.next())
        { 
            String nombre = rs.getString("user_name");
            String contrasena = rs.getString("password");
            tableModel.addRow(new Object[]{nombre, contrasena});
        }

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.pack();
        frame.setVisible(true);
    

    }
    //Metodo para insertar usuarios 		
    public static void insertarUsuario(String usuario,String contrasena) throws SQLException
    {
    	Connection con = ConexionBD.getConnection();
        String query="INSERT INTO USUARIOS (user_name, password, borrado) values (?, ?, ?)";
         PreparedStatement ps = con.prepareStatement(query);

         ps.setString(1, usuario);
         ps.setString(2, contrasena);
         ps.setBoolean(3, false);
         ps.executeUpdate();
    	
    }
    public static void main(String[] args) {
        Connection pruebacn = ConexionBD.getConnection();
        if (pruebacn != null) {
            System.out.println("Conexión realizada con éxito");
            System.out.println(pruebacn);
        } else {
            System.out.println("Desconectado");
        }
    }
}



