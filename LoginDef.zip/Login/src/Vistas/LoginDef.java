package Vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PaqueteLogin.ConexionBD;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.Toolkit;




/**
 * Clase donde se crea la ventana principal
 */
public class LoginDef extends JFrame 
{
	
	//Elementos de la ventana
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldUser;
	private JLabel lblNewLabel_1;
	private JTextField textFieldcon;
	private JButton btnEntrar;
	private JLabel lblNewLabel_2;
	private JLabel textoOculto;
	private JButton btnVerUsuarios;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginDef frame = new LoginDef();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

//El frame donde se colocaran los elementos
	public LoginDef() 
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 332);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Usuario:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(118, 86, 61, 14);
		contentPane.add(lblNewLabel);
		
		textFieldUser = new JTextField();
		textFieldUser.setBounds(245, 83, 133, 27);
		contentPane.add(textFieldUser);
		textFieldUser.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Contraseña:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(118, 135, 100, 14);
		contentPane.add(lblNewLabel_1);
		
		textFieldcon = new JTextField();
		textFieldcon.setBounds(245, 129, 133, 27);
		contentPane.add(textFieldcon);
		
		btnEntrar = new JButton("Entrar");
		btnEntrar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnEntrar.addActionListener(new ActionListener()//Se añade la acción del boton que llamará a otra ventana 
		{
			public void actionPerformed(ActionEvent e) 
			{
				ConexionBD cb = new ConexionBD();
				String usuario = textFieldUser.getText();
				String con = textFieldcon.getText();
				
				
				if(usuario.contains("admin") && con.contains("1234"))//Se comprueba si es el administrador
				{
					
					LoginUsuarios user1 = new LoginUsuarios();
					
					user1.setVisible(true);
					
					
				}
				else
				{
					textoOculto.setText("Usuario o contraseña inválidos");
					
				}
				
				
			}
		});
		btnEntrar.setBounds(118, 186, 116, 41);
		contentPane.add(btnEntrar);
		
		lblNewLabel_2 = new JLabel("Acceso del Admin");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 33));
		lblNewLabel_2.setBounds(111, 11, 309, 41);
		contentPane.add(lblNewLabel_2);
		
		textoOculto = new JLabel("");
		textoOculto.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textoOculto.setForeground(new Color(255, 0, 0));
		textoOculto.setBounds(118, 238, 313, 44);
		contentPane.add(textoOculto);
		
		btnVerUsuarios = new JButton("Ver Usuarios");
		btnVerUsuarios.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnVerUsuarios.addActionListener(new ActionListener()//Aqui se crea la accion del boton la cual será 
		{
			public void actionPerformed(ActionEvent e) 
			{
				
				ConexionBD cb = new ConexionBD();
				String usuario = textFieldUser.getText();
				String con = textFieldcon.getText();
			
				
				if(usuario.contains("admin") && con.contains("1234"))
				{
					
					try
					{
						cb.mostrarUsuarios();
					} 
					catch (SQLException e1)
					{
						e1.printStackTrace();
					}
					
				}
				else
				{
					textoOculto.setText("Usuario o contraseña inválidos");
					
				}
				
				
				
			}
		});
		btnVerUsuarios.setBounds(262, 186, 116, 41);
		contentPane.add(btnVerUsuarios);
	}
	
	
	

	public JTextField getTextField() {
		return textFieldUser;
	}

	public void setTextField(JTextField textField) {
		this.textFieldUser = textField;
	}


	
}



