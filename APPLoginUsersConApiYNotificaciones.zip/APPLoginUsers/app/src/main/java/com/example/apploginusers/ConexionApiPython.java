package com.example.apploginusers;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.util.Log;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class ConexionApiPython extends AppCompatActivity {
    TextView textview;
    LinearLayout container;
    ConexionBD cb;

    private static final String FALLS_PREFS = "falls_prefs";
    private static final String FALLS_KEY = "falls_key";
    private static final String CHANNEL_ID = "channel_id";

    interface RequestUser {
        @GET("/caidas")
        Call<Trigger> getTrigger();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conexion_api_python);
        textview = findViewById(R.id.textView2);
        container = findViewById(R.id.container);
        cb = new ConexionBD();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.26.19.127:5000")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RequestUser requestUser = retrofit.create(RequestUser.class);
        requestUser.getTrigger().enqueue(new Callback<Trigger>() {
            @Override
            public void onResponse(Call<Trigger> call, Response<Trigger> response) {
                if (response.isSuccessful()) {
                    Trigger trigger = response.body();
                    assert trigger != null;
                    String cameraName = trigger.getCameraName();
                    String state = trigger.getState();
                    textview.setText("Camera Name: " + cameraName + "\nState: " + state);
                    if (state.equals("Fall")) {
                        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        Date date = new Date();
                        String usuario = UserManager.getInstance().getUser();
                        try {
                            cb.insertarCaida(cameraName,dateFormat.format(date),usuario);
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                        loadUnvisualizedFalls();
                        addFallDetectedLabel(cameraName, dateFormat.format(date), usuario);
                        createNotificationChannel();
                        showNotification("Notificación", "Se ha detectado una caída");

                    }
                } else {
                    textview.setText("Error en la respuesta de la API");
                }
            }

            @Override
            public void onFailure(Call<Trigger> call, Throwable t) {
                textview.setText(t.getMessage());
            }
        });
    }
    private void loadUnvisualizedFalls() {
        List<Fall> falls = cb.getUnvisualizedFalls();
        for (Fall fall : falls) {
            addFallDetectedLabel(fall.getCameraName(), fall.getDate(), fall.getUser());

        }
    }
    private void addFallDetectedLabel(String cameraName, String date, String user) {
        TextView fallLabel = new TextView(this);
        fallLabel.setText(String.format("Caída detectada\nCámara: %s\nHora: %s\nUsuario: %s", cameraName, date, user));
        fallLabel.setPadding(16, 16, 16, 16);
        fallLabel.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        // Aplicar el estilo definido
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            fallLabel.setTextAppearance(R.style.FallLabelText);
        } else {
            fallLabel.setTextAppearance(this, R.style.FallLabelText);
        }
        fallLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cb.markFallAsVisualized(date);
                container.removeView(fallLabel);
            }
        });
        container.addView(fallLabel);

    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Canal 1"; // Nombre del canal de notificación
            String description = "Descripción del canal"; // Descripción del canal de notificación
            int importance = NotificationManager.IMPORTANCE_DEFAULT; // Importancia del canal
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);//Canal de notificación
            channel.setDescription(description);
            // Registrar el canal de notificación en el sistema
            NotificationManager notificationManager = getSystemService(NotificationManager.class);

            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            } else {
                Log.e("TAG", "El NotificationManager es nulo");
            }
        }
    }
    private void showNotification(String title, String message) {
        // Crear una intención para abrir la actividad principal cuando se hace clic en la notificación
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);

        // Crear y configurar la notificación
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info) // Icono predeterminado de Android
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        // Obtener el gestor de notificaciones
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Mostrar la notificación
        if (notificationManager != null) {
            notificationManager.notify(0, notificationBuilder.build());
        }
    }
}