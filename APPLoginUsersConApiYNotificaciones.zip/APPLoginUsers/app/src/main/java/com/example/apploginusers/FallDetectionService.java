package com.example.apploginusers;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class FallDetectionService extends Service {
    private static final String CHANNEL_ID = "FallDetectionServiceChannel";
    private ConexionBD cb;

    @Override
    public void onCreate() {
        super.onCreate();
        cb = new ConexionBD();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, getNotification("Fall Detection Service", "Running..."));
        checkForFalls();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void checkForFalls() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.26.19.127:5000")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ConexionApiPython.RequestUser requestUser = retrofit.create(ConexionApiPython.RequestUser.class);

        requestUser.getTrigger().enqueue(new Callback<Trigger>() {
            @Override
            public void onResponse(Call<Trigger> call, Response<Trigger> response) {
                if (response.isSuccessful()) {
                    Trigger trigger = response.body();
                    if (trigger != null) {
                        String cameraName = trigger.getCameraName();
                        String state = trigger.getState();
                        if (state.equals("Fall")) {
                            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Date date = new Date();
                            String usuario = UserManager.getInstance().getUser();
                            try {
                                cb.insertarCaida(cameraName, dateFormat.format(date), usuario);
                                showNotification("Fall Detected", "A fall has been detected!");
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Trigger> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Fall Detection Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }

    private Notification getNotification(String title, String message) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .build();
    }

    private void showNotification(String title, String message) {
        Notification notification = getNotification(title, message);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(2, notification);
        }
    }
}
