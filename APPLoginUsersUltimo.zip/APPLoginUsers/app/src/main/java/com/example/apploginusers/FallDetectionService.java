package com.example.apploginusers;import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import android.os.Looper;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;


public class FallDetectionService extends Service {
    private static final String CHANNEL_ID = "FallDetectionServiceChannel";

    private static final int NOTIFICATION_ID = 1234; // ID de la notificación

    private ConexionBD cb;
    private static final long INTERVAL = 1000;
    private boolean isRunning = false;
    private Thread backgroundThread;

    interface RequestUser {
        @GET("/caidas")
        Call<Trigger> getTrigger();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        cb = new ConexionBD();
        startForeground(NOTIFICATION_ID, createNotification()); // Iniciar el servicio en primer plano sin mostrar una notificación

        backgroundThread = new Thread(new Runnable() {
            @Override
            public void run() {
                startRepeatingRequest();
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning) {
            backgroundThread.start();
            isRunning = true;
        }
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void startRepeatingRequest() {
        while (isRunning) {
            makeApiRequest();
            try {
                Thread.sleep(INTERVAL);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void stopRepeatingRequest() {
        isRunning = false;
        backgroundThread.interrupt();
    }

    private void makeApiRequest() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.26.19.127:5000")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ConexionApiPython.RequestUser requestUser = retrofit.create(ConexionApiPython.RequestUser.class);
        requestUser.getTrigger().enqueue(new Callback<Trigger>() {
            @Override
            public void onResponse(Call<Trigger> call, Response<Trigger> response) {
                if (response.isSuccessful()) {
                    Trigger trigger = response.body();
                    assert trigger != null;
                    String cameraName = trigger.getCameraName();
                    String state = trigger.getState();
                    if (state.equals("Fall")) {
                        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        Date date = new Date();
                        String fecha = dateFormat.format(date);
                        String usuario = UserManager.getInstance().getUser();
                        try {
                            cb.insertarCaida(cameraName, fecha, usuario);
                            showToast("Caida detectada: " + cameraName);
                        } catch (SQLException e) {
                            e.printStackTrace();
                            showToast("Error al insertar caída: " + e.getMessage());
                        }
                    }
                }

            }

            @Override
            public void onFailure(Call<Trigger> call, Throwable t) {
                t.printStackTrace();

            }
        });
    }
    private Notification createNotification() {
        NotificationChannel channel = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channel = new NotificationChannel(CHANNEL_ID, "Fall Detection Service", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Fall Detection Service")
                .setContentText("Running...")
                .setContentIntent(pendingIntent)
                .build();
    }
    private void showToast(final String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
