package com.example.apploginusers;
import com.google.gson.annotations.SerializedName;

public class Trigger {
    @SerializedName("camera_name")
    private String cameraName;

    private String state;

    public Trigger(String cameraName, String state) {
        this.cameraName = cameraName;
        this.state = state;
    }

    public String getCameraName() {
        return cameraName;
    }

    public void setCameraName(String cameraName) {
        this.cameraName = cameraName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}