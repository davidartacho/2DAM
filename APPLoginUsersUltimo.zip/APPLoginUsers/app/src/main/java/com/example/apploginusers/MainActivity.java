package com.example.apploginusers;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText textFieldUser;
    private EditText textFieldPassword;
    private Button botonEntrar;

    //Aqui estan los datos de la base de datos
    private static String url = "jdbc:postgresql://172.26.19.127:5432/APP";
    private static String driver = "org.postgresql.Driver";
    private static Connection cn;
    private static String usuario = "postgres";
    private static String contrasenia = "root";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Intent serviceIntent = new Intent(this, FallDetectionService.class);
        startService(serviceIntent);
        try {
            Class.forName(driver);
            cn = DriverManager.getConnection(url,usuario,contrasenia);
            cn.close();

        }
        catch (ClassNotFoundException | SQLException e)
        {
            Toast.makeText(MainActivity.this, "No funciono :(", Toast.LENGTH_SHORT).show();

        }
        botonEntrar = findViewById(R.id.BotonEntrar);

        botonEntrar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view)
            {

                textFieldUser = findViewById(R.id.TextFieldUser);
                textFieldPassword = findViewById(R.id.TextFieldPassword);

                String user = textFieldUser.getText().toString();
                String pass = textFieldPassword.getText().toString();
                UserManager.getInstance().setUser(user);
                ConexionBD cb = new ConexionBD();
                try
                {

                    String comUser = cb.comprobarUser(user);
                    String comCon = cb.comprobarCon(pass);
                    if (user.equals(comUser)&& pass.equals(comCon) )
                    {
                       // if (pass.length() >= 8)
                        {
                            Toast.makeText(MainActivity.this, "¡Bienvenido/a! " + user , Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(MainActivity.this,ConexionApiPython.class);
                            startActivity(i);
                        }
                        //else
                        {
                            //Toast.makeText(MainActivity.this, "Contraseña inferior a 8 caracteres", Toast.LENGTH_SHORT).show();

                        }

                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Usuario o contraseña inválidos", Toast.LENGTH_SHORT).show();


                    }
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }

            }
        });

    }
}