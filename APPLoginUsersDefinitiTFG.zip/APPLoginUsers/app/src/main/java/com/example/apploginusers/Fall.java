package com.example.apploginusers;
public class Fall {
    int id;
    String cameraName;
    String date;
    String user;

    Fall(int id, String cameraName, String date, String user) {
        this.id = id;
        this.cameraName = cameraName;
        this.date = date;
        this.user = user;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCameraName() {
        return cameraName;
    }

    public void setCameraName(String cameraName) {
        this.cameraName = cameraName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}