package com.example.apploginusers;import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import android.os.Looper;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;


public class FallDetectionService extends Service {
    private static final String CHANNEL_ID = "FallDetectionServiceChannel";

    private static final int NOTIFICATION_ID = 1234; // ID de la notificación

    private ConexionBD cb;
    private static final long INTERVAL = 2000;
    private boolean isRunning = false;
    private Thread backgroundThread;

    interface RequestUser {
        @GET("/caidas")
        Call<Trigger> getTrigger();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        cb = new ConexionBD();
        //startForeground(NOTIFICATION_ID, createNotification());


        backgroundThread = new Thread(new Runnable() {
            @Override
            public void run() {
                startRepeatingRequest();
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        if (!isRunning) {
            backgroundThread.start();
            isRunning = true;
        }
        Notification notification = createNotification();

        startForeground(NOTIFICATION_ID, notification);// Iniciar el servicio en primer plano sin mostrar una notificación


        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void startRepeatingRequest() {
        while (isRunning) {
            makeApiRequest();
            try {
                Thread.sleep(INTERVAL);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void stopRepeatingRequest() {
        isRunning = false;
        backgroundThread.interrupt();
    }

    private void makeApiRequest() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.26.19.127:5000")
                .addConverterFactory(GsonConverterFactory.create())
                .build();


        ConexionApiPython.RequestUser requestUser = retrofit.create(ConexionApiPython.RequestUser.class);
        requestUser.getTrigger().enqueue(new Callback<Trigger>() {
            @Override
            public void onResponse(Call<Trigger> call, Response<Trigger> response) {
                if (response.isSuccessful()) {
                    Trigger trigger = response.body();
                    assert trigger != null;
                    String cameraName = trigger.getCameraName();
                    String state = trigger.getState();
                    if (state.equals("Fall")) {
                        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        Date date = new Date();
                        String fecha = dateFormat.format(date);
                        String usuario = UserManager.getInstance().getUser();
                        try {
                            cb.insertarCaida(cameraName, fecha, usuario);
                            showToast("Caida detectada: " + cameraName);
                        } catch (SQLException e) {
                            e.printStackTrace();
                            showToast("Error al insertar caída: " + e.getMessage());
                        }
                        enviarNotificacion();
                    }
                }

            }

            @Override
            public void onFailure(Call<Trigger> call, Throwable t) {
                t.printStackTrace();

            }
        });
    }
    private Notification createNotification() {


        NotificationChannel channel = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channel = new NotificationChannel(CHANNEL_ID, "Fall Detection Service", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        int colorCarne = getResources().getColor(R.color.colorCarne);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Aplicación Deteccion de Caidas")
                .setContentText("En ejecución")
                .setContentIntent(pendingIntent)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setColor(colorCarne)
                .setAutoCancel(true)
                .build();
    }
    private void enviarNotificacion() {
        Context context = getApplicationContext();
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Crear canal de notificación si es necesario (solo para Android Oreo y superior)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Canal de notificaciones", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        // Crear intent para abrir la actividad principal al hacer clic en la notificación
        Intent intent = new Intent(context, ConexionApiPython.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        int amarillo = ContextCompat.getColor(context, R.color.amarillo);

        // Incrementamos el ID de notificación para evitar la superposición
        int notificationId = NOTIFICATION_ID + 1;

        // Crear la notificación
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setContentTitle("¡Alerta de caída!")
                .setContentText("Se ha detectado una caída.")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pendingIntent)
                .setColor(amarillo)
                .setAutoCancel(true)  // La notificación se elimina al hacer clic en ella
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();

        // Mostrar la notificación
        notificationManager.notify(notificationId, notification);
    }
    private void eniarpopUP(){

        String chanelID = "Canal de Notificaciones";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(),chanelID);

        builder.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("¡Alerta de caída!")
                .setContentText("Se ha detectado una caída.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);
        Intent intent = new Intent(getApplicationContext(), ConexionApiPython.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_MUTABLE);
        builder.setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = notificationManager.getNotificationChannel(chanelID);
            if(notificationChannel ==null)
            {
                int importance = NotificationManager.IMPORTANCE_HIGH;
                notificationChannel = new NotificationChannel(chanelID,"cacaad",importance);
                notificationChannel.setLightColor(Color.BLACK);
                notificationChannel.enableVibration(true);
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        notificationManager.notify(0,builder.build());

        }

    private void showToast(final String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
