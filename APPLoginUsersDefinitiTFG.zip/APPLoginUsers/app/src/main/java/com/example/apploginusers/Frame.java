package com.example.apploginusers;
public class Frame {
    private String imageUrl;  // URL de la imagen, puedes cambiar el nombre según sea necesario

    public Frame(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}