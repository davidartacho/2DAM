package com.example.apploginusers;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.StrictMode;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import android.Manifest;

public class MainActivity extends AppCompatActivity {

    private EditText textFieldUser;
    private EditText textFieldPassword;
    private Button botonEntrar;
    private static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 2;

    //Aqui estan los datos de la base de datos
    private static String url = "jdbc:postgresql://172.26.19.127:5432/APP";
    private static String driver = "org.postgresql.Driver";
    private static Connection cn;
    private static String usuario = "postgres";
    private static String contrasenia = "root";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Verificar y solicitar la exclusión de la optimización de batería

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            String packageName = getPackageName();
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                alertaOptimizacionBateria();
            }
        }
        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST_CODE);
            }
        }
        try {
            Class.forName(driver);
            cn = DriverManager.getConnection(url,usuario,contrasenia);
            cn.close();
            Toast.makeText(MainActivity.this, "Conexión exitosa :)", Toast.LENGTH_SHORT).show();

        }
        catch (ClassNotFoundException e) {
            // Manejar error de driver no encontrado
            Toast.makeText(MainActivity.this, "Error: Driver no encontrado", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        catch (SQLException e) {
            // Manejar error de conexión
            Toast.makeText(MainActivity.this, "Error: No se pudo conectar a la base de datos", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        Intent serviceIntent = new Intent(this, FallDetectionService.class);
        startService(serviceIntent);
        botonEntrar = findViewById(R.id.BotonEntrar);

        botonEntrar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view)
            {

                textFieldUser = findViewById(R.id.TextFieldUser);
                textFieldPassword = findViewById(R.id.TextFieldPassword);

                String user = textFieldUser.getText().toString();
                String pass = textFieldPassword.getText().toString();
                UserManager.getInstance().setUser(user);
                ConexionBD cb = new ConexionBD();
                try
                {

                    String comUser = cb.comprobarUser(user);
                    String comCon = cb.comprobarCon(pass);
                    if (user.equals(comUser)&& pass.equals(comCon) )
                    {
                       // if (pass.length() >= 8)
                        {
                            Toast.makeText(MainActivity.this, "¡Bienvenido/a! " + user , Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(MainActivity.this,ConexionApiPython.class);
                            startActivity(i);
                        }
                        //else
                        {
                            //Toast.makeText(MainActivity.this, "Contraseña inferior a 8 caracteres", Toast.LENGTH_SHORT).show();

                        }

                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Usuario o contraseña inválidos", Toast.LENGTH_SHORT).show();


                    }
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }

            }
        });

    }
    private void alertaOptimizacionBateria() {
        new AlertDialog.Builder(this)
                .setTitle("Optimización de Batería")
                .setMessage("Para un mejor rendimiento, desactiva la optimización de batería para esta aplicación.")
                .setPositiveButton("Aceptar", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}