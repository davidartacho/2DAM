package com.example.apploginusers;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.util.Log;
import android.view.Gravity;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class ConexionApiPython extends AppCompatActivity {
    TextView textview;
    LinearLayout container;
    ConexionBD cb;

    private static final String FALLS_PREFS = "falls_prefs";
    private static final String FALLS_KEY = "falls_key";
    private static final String CHANNEL_ID = "channel_id";

    interface RequestUser {
        @GET("/caidas")
        Call<Trigger> getTrigger();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conexion_api_python);
        textview = findViewById(R.id.textView2);
        container = findViewById(R.id.container);
        cb = new ConexionBD();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.26.19.127:5000")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RequestUser requestUser = retrofit.create(RequestUser.class);
        requestUser.getTrigger().enqueue(new Callback<Trigger>() {
            @Override
            public void onResponse(Call<Trigger> call, Response<Trigger> response) {
                loadUnvisualizedFalls();
                if (response.isSuccessful()) {
                    Trigger trigger = response.body();
                    assert trigger != null;
                    String cameraName = trigger.getCameraName();
                    String state = trigger.getState();
                    if (state.equals("Fall")) {
                        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        Date date = new Date();
                        String fecha = dateFormat.format(date);
                        String usuario = UserManager.getInstance().getUser();
                        try {
                            cb.insertarCaida(cameraName,fecha,usuario);
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                        int id = 0;
                        try {
                            id = cb.getLastInsertedFallId();
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                        addFallDetectedLabel(id, cameraName, fecha, usuario);


                    }
                } else {
                    textview.setText("Error en la respuesta de la API");
                }
            }

            @Override
            public void onFailure(Call<Trigger> call, Throwable t) {
                textview.setText(t.getMessage());
            }
        });
    }
    private void loadUnvisualizedFalls() {
        List<Fall> falls = cb.getUnvisualizedFalls();
        for (Fall fall : falls) {
            addFallDetectedLabel(fall.getId(), fall.getCameraName(), fall.getDate(), fall.getUser());

        }
    }
    private void addFallDetectedLabel(int id,String cameraName, String date, String user) {
        TextView fallLabel = new TextView(this);
        fallLabel.setText(String.format("Caída detectada\nUbicación: %s\nFecha: %s\nUsuario: %s", cameraName, date, user));
        fallLabel.setPadding(16, 16, 16, 16);
        fallLabel.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // Aplicar el estilo definido
            fallLabel.setTextAppearance(R.style.FallLabelText);
            fallLabel.setBackground(getResources().getDrawable(R.drawable.fall_label_background));

        fallLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cb.markFallAsVisualized(id);
                container.removeView(fallLabel);

            }
        });
        container.addView(fallLabel);

    }


}